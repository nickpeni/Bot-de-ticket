"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const Event_1 = require("../../interfaces/types/Event");
const __1 = require("../..");
exports.default = new Event_1.Event({
    name: "interactionCreate",
    run(interaction) {
        if (!interaction.isCommand())
            return;
        const command = __1.client.commands.get(interaction.commandName);
        if (!command)
            return;
        if (interaction.isAutocomplete() && command.autoComplete) {
            command.autoComplete(interaction);
            return;
        }
        if (interaction.isChatInputCommand()) {
            const options = interaction.options;
            command.run({ client: __1.client, interaction, options });
            return;
        }
    },
});
