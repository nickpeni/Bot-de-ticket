"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const index_1 = require("../../index");
const discord_html_transcripts_1 = require("discord-html-transcripts");
const discord_js_1 = require("discord.js");
const wio_db_1 = require("wio.db");
const Command_1 = require("../../interfaces/types/Command");
const db = new wio_db_1.JsonDatabase({ databasePath: "./database/code.json" });
const map = new Map();
exports.default = new Command_1.Command({
  name: "ticket",
  description: "Execute para enviar o sistema de ticket",
  type: discord_js_1.ApplicationCommandType.ChatInput,
  async run({ interaction }) {
    if (!interaction.inCachedGuild()) return;
    const ticketChannel = interaction.guild.channels.cache.get(
      index_1.config.canais.ticket
    );
    const embedError = new discord_js_1.EmbedBuilder({
      color: 0x2b2d31,
      description: "❌ | Não foi possível enviar o sistema de ticket.",
    });
    const embedSucess = new discord_js_1.EmbedBuilder({
      color: 0x2b2d31,
      description: "✅ | O sistema de ticket foi enviado com sucesso.",
    });
    const embedTicket = new discord_js_1.EmbedBuilder({
      author: {
        name: interaction.guild.name,
        iconURL: interaction.guild.iconURL() ?? undefined,
      },
      color: 0x2b2d31,
      description: "Para abrir um ticket clique no botão abaixo.",
    });
    const buttonShortcut = new discord_js_1.ActionRowBuilder({
      components: [
        new discord_js_1.ButtonBuilder({
          url: ticketChannel.url,
          emoji: "🔗",
          label: "Ir para Ticket",
          style: discord_js_1.ButtonStyle.Link,
        }),
      ],
    });
    const buttonTicket = new discord_js_1.ActionRowBuilder({
      components: [
        new discord_js_1.ButtonBuilder({
          customId: "open-ticket",
          emoji: "🎫",
          label: "Abrir Ticket",
          style: discord_js_1.ButtonStyle.Secondary,
        }),
      ],
    });
    try {
      ticketChannel.send({ embeds: [embedTicket], components: [buttonTicket] });
      interaction.reply({
        embeds: [embedSucess],
        components: [buttonShortcut],
        ephemeral: true,
      });
    } catch (error) {
      interaction.reply({ embeds: [embedError], ephemeral: true });
    }
  },
  buttons: new discord_js_1.Collection([
    [
      "open-ticket",
      async (interaction) => {
        if (!interaction.inCachedGuild()) return;
        const parentTicket = interaction.guild.channels.cache.get(
          index_1.config.categorias.ticket
        );
        const roleTicket = interaction.guild.roles.cache.get(
          index_1.config.cargos.adminTicket
        );
        const ticketChannel = interaction.guild.channels.cache.find(
          (channel) =>
            channel.type === discord_js_1.ChannelType.GuildText &&
            channel.topic === interaction.user.id
        );
        if (ticketChannel) {
          const embedWarning = new discord_js_1.EmbedBuilder({
            color: 0x2b2d31,
            description: "❌ | Você já possui um ticket aberto.",
          });
          const buttonShortcut = new discord_js_1.ActionRowBuilder({
            components: [
              new discord_js_1.ButtonBuilder({
                url: ticketChannel.url,
                emoji: "🔗",
                label: "Ir para Ticket",
                style: discord_js_1.ButtonStyle.Link,
              }),
            ],
          });
          interaction.reply({
            embeds: [embedWarning],
            components: [buttonShortcut],
            ephemeral: true,
          });
        } else {
          interaction.guild.channels
            .create({
              name: "🎫-" + interaction.user.username,
              topic: interaction.user.id,
              type: discord_js_1.ChannelType.GuildText,
              parent: parentTicket.id,
              permissionOverwrites: [
                {
                  id: interaction.guild.id,
                  deny: ["ViewChannel"],
                },
                {
                  id: interaction.user.id,
                  allow: [
                    "ViewChannel",
                    "SendMessages",
                    "AttachFiles",
                    "EmbedLinks",
                    "ReadMessageHistory",
                  ],
                },
                {
                  id: roleTicket.id,
                  allow: [
                    "ViewChannel",
                    "SendMessages",
                    "AttachFiles",
                    "EmbedLinks",
                    "ReadMessageHistory",
                  ],
                },
              ],
            })
            .then((ticketChannel) => {
              const embedError = new discord_js_1.EmbedBuilder({
                color: 0x2b2d31,
                description: "❌ | Não foi possível criar o seu ticket.",
              });
              const embedWarning = new discord_js_1.EmbedBuilder({
                color: 0x2b2d31,
                description: "✅ | Seu ticket foi aberto.",
              });
              const embedTicket = new discord_js_1.EmbedBuilder({
                author: {
                  name: interaction.guild.name,
                  iconURL: interaction.guild.iconURL() ?? undefined,
                },
                color: 0x2b2d31,
                description: `${interaction.user} Esse canal é para seu suporte para melhor atendimento informe algo sobre.`,
              });
              const buttonShortcut = new discord_js_1.ActionRowBuilder({
                components: [
                  new discord_js_1.ButtonBuilder({
                    url: ticketChannel.url,
                    emoji: "🔗",
                    label: "Ir para Ticket",
                    style: discord_js_1.ButtonStyle.Link,
                  }),
                ],
              });
              const buttonsTicket = new discord_js_1.ActionRowBuilder({
                components: [
                  new discord_js_1.ButtonBuilder({
                    customId: "close-ticket",
                    emoji: "🔒",
                    label: "Fechar Ticket",
                    style: discord_js_1.ButtonStyle.Secondary,
                  }),
                  new discord_js_1.ButtonBuilder({
                    customId: "assume-ticket",
                    emoji: "🙋‍♂️",
                    label: "Assumir Ticket",
                    style: discord_js_1.ButtonStyle.Secondary,
                  }),
                  new discord_js_1.ButtonBuilder({
                    customId: "panel-ticket",
                    emoji: "👮",
                    label: "Painel Staff",
                    style: discord_js_1.ButtonStyle.Secondary,
                  }),
                  new discord_js_1.ButtonBuilder({
                    customId: "exit-ticket",
                    emoji: "👋",
                    label: "Sair Ticket",
                    style: discord_js_1.ButtonStyle.Secondary,
                  }),
                ],
              });
              try {
                ticketChannel.send({
                  embeds: [embedTicket],
                  components: [buttonsTicket],
                });
                interaction.reply({
                  embeds: [embedWarning],
                  components: [buttonShortcut],
                  ephemeral: true,
                });
              } catch (error) {
                interaction.reply({ embeds: [embedError], ephemeral: true });
              }
            });
        }
      },
    ],
    [
      "exit-ticket",
      async (interaction) => {
        if (!interaction.inCachedGuild()) return;
        const ticketChannel = interaction.channel;
        const userTicket = interaction.guild.members.cache.get(
          ticketChannel.topic
        );
        const embedError = new discord_js_1.EmbedBuilder({
          color: 0x2b2d31,
          description: "❌ | Não foi possível sair do seu ticket.",
        });
        const embedWarning = new discord_js_1.EmbedBuilder({
          color: 0x2b2d31,
          description: "❌ | Você não pode sair desse ticket.",
        });
        const embedSucess = new discord_js_1.EmbedBuilder({
          color: 0x2b2d31,
          description: `✅ | ${userTicket} Saiu do ticket.`,
        });
        if (interaction.user.id !== userTicket.user.id) {
          interaction.reply({ embeds: [embedWarning], ephemeral: true });
          return;
        }
        await db.set(`user_${ticketChannel.id}`, `${ticketChannel.topic}`);
        try {
          interaction.deferUpdate();
          ticketChannel.permissionOverwrites.edit(userTicket.id, {
            ViewChannel: false,
            SendMessages: false,
            AttachFiles: false,
            EmbedLinks: false,
            ReadMessageHistory: false,
          });
          ticketChannel.send({ embeds: [embedSucess] });
          ticketChannel.setTopic("Usuário saiu do ticket");
        } catch (error) {
          interaction.reply({ embeds: [embedError], ephemeral: true });
        }
      },
    ],
    [
      "panel-ticket",
      async (interaction) => {
        if (!interaction.inCachedGuild()) return;
        const roleTicket = interaction.guild.roles.cache.get(
          index_1.config.cargos.adminTicket
        );
        const embedError = new discord_js_1.EmbedBuilder({
          color: 0x2b2d31,
          description: "❌ | Não foi possível abrir o painel staff.",
        });
        const embedPermission = new discord_js_1.EmbedBuilder({
          color: 0x2b2d31,
          description: "❌ | Você está sem permissão para usar esse botão.",
        });
        if (!interaction.member.roles.cache.has(roleTicket.id)) {
          interaction.reply({ embeds: [embedPermission], ephemeral: true });
          return;
        } else {
          const embedPanel = new discord_js_1.EmbedBuilder({
            color: 0x2b2d31,
            description: "✅ | Escolhar algumas das opções abaixo.",
          });
          const buttonsPanel = new discord_js_1.ActionRowBuilder({
            components: [
              new discord_js_1.ButtonBuilder({
                customId: "notify-user",
                emoji: "🔔",
                label: "Notificar Usuário",
                style: discord_js_1.ButtonStyle.Secondary,
              }),
              new discord_js_1.ButtonBuilder({
                customId: "add-user",
                emoji: "👥",
                label: "Adicionar Usuário",
                style: discord_js_1.ButtonStyle.Secondary,
              }),
              new discord_js_1.ButtonBuilder({
                customId: "remove-user",
                emoji: "👤",
                label: "Remover Usuário",
                style: discord_js_1.ButtonStyle.Secondary,
              }),
              new discord_js_1.ButtonBuilder({
                customId: "lock-ticket",
                emoji: "🔐",
                label: "Bloquear Canal",
                style: discord_js_1.ButtonStyle.Secondary,
              }),
              new discord_js_1.ButtonBuilder({
                customId: "unlock-ticket",
                emoji: "🔓",
                label: "Desbloquear Canal",
                style: discord_js_1.ButtonStyle.Secondary,
              }),
            ],
          });
          try {
            interaction.reply({
              embeds: [embedPanel],
              components: [buttonsPanel],
              ephemeral: true,
            });
          } catch (error) {
            interaction.reply({ embeds: [embedError], ephemeral: true });
          }
        }
      },
    ],
    [
      "unlock-ticket",
      async (interaction) => {
        if (!interaction.inCachedGuild()) return;
        const ticketChannel = interaction.channel;
        const userTicket = interaction.guild.members.cache.get(
          ticketChannel.topic
        );
        const embedError = new discord_js_1.EmbedBuilder({
          color: 0x2b2d31,
          description: "❌ | Não foi possível desbloquear o chat desse ticket.",
        });
        const embedSucess = new discord_js_1.EmbedBuilder({
          color: 0x2b2d31,
          description: `✅ | Chat desse ticket desbloqueado com sucesso.`,
        });
        try {
          interaction.deferUpdate();
          ticketChannel.permissionOverwrites.edit(userTicket.id, {
            SendMessages: true,
          });
          ticketChannel.send({ embeds: [embedSucess] });
        } catch (error) {
          interaction.reply({ embeds: [embedError], ephemeral: true });
        }
      },
    ],
    [
      "lock-ticket",
      async (interaction) => {
        if (!interaction.inCachedGuild()) return;
        const ticketChannel = interaction.channel;
        const userTicket = interaction.guild.members.cache.get(
          ticketChannel.topic
        );
        const embedError = new discord_js_1.EmbedBuilder({
          color: 0x2b2d31,
          description: "❌ | Não foi possível bloquear o chat desse ticket.",
        });
        const embedSucess = new discord_js_1.EmbedBuilder({
          color: 0x2b2d31,
          description: `✅ | Chat desse ticket bloqueado com sucesso.`,
        });
        try {
          interaction.deferUpdate();
          ticketChannel.permissionOverwrites.edit(userTicket.id, {
            SendMessages: false,
          });
          ticketChannel.send({ embeds: [embedSucess] });
        } catch (error) {
          interaction.reply({ embeds: [embedError], ephemeral: true });
        }
      },
    ],
    [
      "remove-user",
      async (interaction) => {
        if (!interaction.inCachedGuild()) return;
        const ticketChannel = interaction.channel;
        const embedError = new discord_js_1.EmbedBuilder({
          color: 0x2b2d31,
          description: "❌ | Não foi possível remover o usuário desse ticket.",
        });
        const embedSucess = new discord_js_1.EmbedBuilder({
          color: 0x2b2d31,
          description: `✅ | Digite o ID do usuário que será removido do ticket.`,
        });
        try {
          interaction
            .reply({ embeds: [embedSucess], ephemeral: true })
            .then(() => {
              const collector = ticketChannel.createMessageCollector({
                filter: (a) => a.author.id === interaction.user.id,
                max: 1,
              });
              collector.on("collect", async (m) => {
                const userId = m.content;
                const newUserTicket =
                  interaction.guild.members.cache.get(userId);
                if (!newUserTicket) {
                  ticketChannel.send({ embeds: [embedError] });
                  return;
                }
                const newEmbedSucess = new discord_js_1.EmbedBuilder({
                  color: 0x2b2d31,
                  description: `✅ | Usuário ${newUserTicket} foi removido com sucesso.`,
                });
                try {
                  ticketChannel.permissionOverwrites.edit(newUserTicket.id, {
                    ViewChannel: false,
                    SendMessages: false,
                    AttachFiles: false,
                    EmbedLinks: false,
                    ReadMessageHistory: false,
                  });
                  ticketChannel.send({ embeds: [newEmbedSucess] });
                } catch (error) {
                  interaction.reply({ embeds: [embedError], ephemeral: true });
                }
              });
            });
        } catch (error) {
          interaction.reply({ embeds: [embedError], ephemeral: true });
        }
      },
    ],
    [
      "add-user",
      async (interaction) => {
        if (!interaction.inCachedGuild()) return;
        const ticketChannel = interaction.channel;
        const embedError = new discord_js_1.EmbedBuilder({
          color: 0x2b2d31,
          description: "❌ | Não foi possível adicionar o usuário ao ticket.",
        });
        const embedSucess = new discord_js_1.EmbedBuilder({
          color: 0x2b2d31,
          description: `✅ | Digite o ID do usuário que será adicionado ao ticket.`,
        });
        try {
          interaction
            .reply({ embeds: [embedSucess], ephemeral: true })
            .then(() => {
              const collector = ticketChannel.createMessageCollector({
                filter: (a) => a.author.id === interaction.user.id,
                max: 1,
              });
              collector.on("collect", async (m) => {
                const userId = m.content;
                const newUserTicket =
                  interaction.guild.members.cache.get(userId);
                if (!newUserTicket) {
                  ticketChannel.send({ embeds: [embedError] });
                  return;
                }
                const newEmbedSucess = new discord_js_1.EmbedBuilder({
                  color: 0x2b2d31,
                  description: `✅ | Usuário ${newUserTicket} foi adicionado com sucesso.`,
                });
                try {
                  ticketChannel.permissionOverwrites.create(newUserTicket.id, {
                    ViewChannel: true,
                    SendMessages: true,
                    AttachFiles: true,
                    EmbedLinks: true,
                    ReadMessageHistory: true,
                  });
                  ticketChannel.send({ embeds: [newEmbedSucess] });
                } catch (error) {
                  interaction.reply({ embeds: [embedError], ephemeral: true });
                }
              });
            });
        } catch (error) {
          interaction.reply({ embeds: [embedError], ephemeral: true });
        }
      },
    ],
    [
      "notify-user",
      async (interaction) => {
        if (!interaction.inCachedGuild()) return;
        const ticketChannel = interaction.channel;
        const userTicket = interaction.guild.members.cache.get(
          ticketChannel.topic
        );
        const embedError = new discord_js_1.EmbedBuilder({
          color: 0x2b2d31,
          description: "❌ | Não foi possível notificar o usuário.",
        });
        const embedSucess = new discord_js_1.EmbedBuilder({
          color: 0x2b2d31,
          description: `✅ | Usuário notificado com sucesso.`,
        });
        const embedUser = new discord_js_1.EmbedBuilder({
          color: 0x2b2d31,
          description: `✅ | Um staff está esperando sua resposta no seu ticket.`,
        });
        const buttonUser = new discord_js_1.ActionRowBuilder({
          components: [
            new discord_js_1.ButtonBuilder({
              url: ticketChannel.url,
              emoji: "🔗",
              label: "Ir para Ticket",
              style: discord_js_1.ButtonStyle.Link,
            }),
          ],
        });
        userTicket
          .send({ embeds: [embedUser], components: [buttonUser] })
          .then(() => {
            interaction.reply({ embeds: [embedSucess], ephemeral: true });
          })
          .catch(() => {
            interaction.reply({ embeds: [embedError], ephemeral: true });
          });
      },
    ],
    [
      "assume-ticket",
      async (interaction) => {
        if (!interaction.inCachedGuild()) return;
        const ticketChannel = interaction.channel;
        const roleTicket = interaction.guild.roles.cache.get(
          index_1.config.cargos.adminTicket
        );
        const embedError = new discord_js_1.EmbedBuilder({
          color: 0x2b2d31,
          description: "❌ | Não foi possível assumir o ticket.",
        });
        const embedPermission = new discord_js_1.EmbedBuilder({
          color: 0x2b2d31,
          description: "❌ | Você está sem permissão para usar esse botão.",
        });
        if (!interaction.member.roles.cache.has(roleTicket.id)) {
          interaction.reply({ embeds: [embedPermission], ephemeral: true });
          return;
        } else {
          await db.set(
            `staff_${ticketChannel.id}`,
            `${interaction.user.username}`
          );
          const newEmbedTicket = new discord_js_1.EmbedBuilder({
            author: {
              name: interaction.guild.name,
              iconURL: interaction.guild.iconURL() ?? undefined,
            },
            color: 0x2b2d31,
            description: `${interaction.user} Esse canal é para seu suporte para melhor atendimento informe algo sobre.`,
            footer: {
              text: `Responsável do Ticket: ${interaction.user.username}`,
            },
          });
          const newButtonsTicket = new discord_js_1.ActionRowBuilder({
            components: [
              new discord_js_1.ButtonBuilder({
                customId: "close-ticket",
                emoji: "🔒",
                label: "Fechar Ticket",
                style: discord_js_1.ButtonStyle.Secondary,
              }),
              new discord_js_1.ButtonBuilder({
                customId: "panel-ticket",
                emoji: "👮",
                label: "Painel Staff",
                style: discord_js_1.ButtonStyle.Secondary,
              }),
              new discord_js_1.ButtonBuilder({
                customId: "exit-ticket",
                emoji: "👋",
                label: "Sair Ticket",
                style: discord_js_1.ButtonStyle.Secondary,
              }),
            ],
          });
          try {
            interaction.update({
              embeds: [newEmbedTicket],
              components: [newButtonsTicket],
            });
          } catch (error) {
            interaction.reply({ embeds: [embedError], ephemeral: true });
          }
        }
      },
    ],
    [
      "close-ticket",
      async (interaction) => {
        if (!interaction.inCachedGuild()) return;
        const roleTicket = interaction.guild.roles.cache.get(
          index_1.config.cargos.adminTicket
        );
        const embedError = new discord_js_1.EmbedBuilder({
          color: 0x2b2d31,
          description: "❌ | Não foi possível fechar o ticket.",
        });
        const embedPermission = new discord_js_1.EmbedBuilder({
          color: 0x2b2d31,
          description: "❌ | Você está sem permissão para usar esse botão.",
        });
        if (!interaction.member.roles.cache.has(roleTicket.id)) {
          interaction.reply({ embeds: [embedPermission], ephemeral: true });
          return;
        } else {
          const embedClosed = new discord_js_1.EmbedBuilder({
            color: 0x2b2d31,
            description: "✅ | Escolhar algumas das opções abaixo.",
          });
          const buttonsClosed = new discord_js_1.ActionRowBuilder({
            components: [
              new discord_js_1.ButtonBuilder({
                customId: "delete-ticket",
                emoji: "🗑️",
                label: "Deletar Ticket",
                style: discord_js_1.ButtonStyle.Secondary,
              }),
              new discord_js_1.ButtonBuilder({
                customId: "save-logs",
                emoji: "💾",
                label: "Salvar Mensagens",
                style: discord_js_1.ButtonStyle.Secondary,
              }),
            ],
          });
          try {
            interaction.reply({
              embeds: [embedClosed],
              components: [buttonsClosed],
              ephemeral: true,
            });
          } catch (error) {
            interaction.reply({ embeds: [embedError], ephemeral: true });
          }
        }
      },
    ],
    [
      "save-logs",
      async (interaction) => {
        if (!interaction.inCachedGuild()) return;
        const embedError = new discord_js_1.EmbedBuilder({
          color: 0x2b2d31,
          description: "❌ | Não foi possível salvar as mensagens do ticket.",
        });
        const ticketChannel = interaction.channel;
        const ticketChannelLogs = interaction.guild.channels.cache.get(
          index_1.config.canais.ticketLogs
        );
        const staffTicket =
          db.get(`staff_${ticketChannel.id}`) || "Sem Responsável";
        const userTicket = interaction.guild.members.cache.get(
          ticketChannel.topic
        );
        const transcriptTicketLogs = await (0,
        discord_html_transcripts_1.createTranscript)(ticketChannel, {
          filename: ticketChannel.name + ".html",
          saveImages: true,
        });
        const embedTicketLogs = new discord_js_1.EmbedBuilder({
          color: 0x2b2d31,
          fields: [
            { name: "🎫 Ticket", value: `${ticketChannel.name}` },
            { name: "👮 Salvo Por", value: `${interaction.user}` },
            {
              name: "⏰ Horário",
              value: `<t:${~~(interaction.createdAt.getTime() / 1000)}:F>`,
            },
          ],
          footer: { text: `Responsável do Ticket: ${staffTicket}` },
        });
        userTicket
          .send({ embeds: [embedTicketLogs], files: [transcriptTicketLogs] })
          .catch(() => {});
        try {
          interaction.deferUpdate();
          ticketChannelLogs.send({
            embeds: [embedTicketLogs],
            files: [transcriptTicketLogs],
          });
        } catch (error) {
          interaction.reply({ embeds: [embedError], ephemeral: true });
        }
      },
    ],
    [
      "delete-ticket",
      async (interaction) => {
        if (!interaction.inCachedGuild()) return;
        const embedError = new discord_js_1.EmbedBuilder({
          color: 0x2b2d31,
          description: "❌ | Não foi possível deletar esse ticket.",
        });
        const ticketChannel = interaction.channel;
        const ticketChannelLogs = interaction.guild.channels.cache.get(
          index_1.config.canais.ticketLogs
        );
        const staffTicket =
          db.get(`staff_${ticketChannel.id}`) || "Sem Responsável";
        const userTicket = interaction.guild.members.cache.get(
          ticketChannel.topic
        );
        const transcriptTicketLogs = await (0,
        discord_html_transcripts_1.createTranscript)(ticketChannel, {
          filename: ticketChannel.name + ".html",
          saveImages: true,
        });
        const embedUser = new discord_js_1.EmbedBuilder({
          title: "Avaliação do Ticket",
          color: 0x2b2d31,
          fields: [
            { name: "⭐", value: "Ruim" },
            { name: "⭐⭐", value: "Ruim / Médio" },
            { name: "⭐⭐⭐", value: "Médio" },
            { name: "⭐⭐⭐⭐", value: "Médio / Bom" },
            { name: "⭐⭐⭐⭐⭐", value: "Bom" },
          ],
        });
        const row = new discord_js_1.ActionRowBuilder({
          components: [
            new discord_js_1.ButtonBuilder({
              customId: "one",
              emoji: "⭐",
              label: "1 Estrela",
              style: discord_js_1.ButtonStyle.Secondary,
            }),
            new discord_js_1.ButtonBuilder({
              customId: "two",
              emoji: "⭐",
              label: "2 Estrela",
              style: discord_js_1.ButtonStyle.Secondary,
            }),
            new discord_js_1.ButtonBuilder({
              customId: "tree",
              emoji: "⭐",
              label: "3 Estrela",
              style: discord_js_1.ButtonStyle.Secondary,
            }),
            new discord_js_1.ButtonBuilder({
              customId: "four",
              emoji: "⭐",
              label: "4 Estrela",
              style: discord_js_1.ButtonStyle.Secondary,
            }),
            new discord_js_1.ButtonBuilder({
              customId: "five",
              emoji: "⭐",
              label: "5 Estrela",
              style: discord_js_1.ButtonStyle.Secondary,
            }),
          ],
        });
        const embedTicketLogs = new discord_js_1.EmbedBuilder({
          color: 0x2b2d31,
          fields: [
            { name: "🎫 Ticket", value: `${ticketChannel.name}` },
            { name: "👮 Salvo Por", value: `${interaction.user}` },
            {
              name: "⏰ Horário",
              value: `<t:${~~(interaction.createdAt.getTime() / 1000)}:F>`,
            },
          ],
          footer: { text: `Responsável do Ticket: ${staffTicket}` },
        });
        await userTicket
          .send({ embeds: [embedTicketLogs], files: [transcriptTicketLogs] })
          .catch(() => {});
        await userTicket
          .send({ embeds: [embedUser], components: [row] })
          .catch(() => {});
        try {
          interaction.deferUpdate();
          await ticketChannelLogs.send({
            embeds: [embedTicketLogs],
            files: [transcriptTicketLogs],
          });
          setInterval(() => {
            ticketChannel.delete().catch(() => {});
          }, 15000);
        } catch (error) {
          interaction.reply({ embeds: [embedError], ephemeral: true });
        }
      },
    ],
    [
      "one",
      async (interaction) => {
        const channel = index_1.client.channels.cache.get(
          index_1.config.canais.ticketAvaliações
        );
        interaction.update({ components: [] });
        const embed = new discord_js_1.EmbedBuilder({
          title: "Nova Avaliação",
          color: 0x2b2d31,
          fields: [{ name: "⭐", value: "Atendimento Ruim" }],
          footer: { text: "Feita por" + interaction.user.username },
        });
        channel.send({
          embeds: [embed],
        });
      },
    ],
    [
      "two",
      async (interaction) => {
        const channel = index_1.client.channels.cache.get(
          index_1.config.canais.ticketAvaliações
        );
        interaction.update({ components: [] });
        const embed = new discord_js_1.EmbedBuilder({
          title: "Nova Avaliação",
          color: 0x2b2d31,
          fields: [{ name: "⭐⭐", value: "Atendimento Ruim / Médio" }],
          footer: { text: "Feita por" + interaction.user.username },
        });
        channel.send({
          embeds: [embed],
        });
      },
    ],
    [
      "two",
      async (interaction) => {
        const channel = index_1.client.channels.cache.get(
          index_1.config.canais.ticketAvaliações
        );
        interaction.update({ components: [] });
        const embed = new discord_js_1.EmbedBuilder({
          title: "Nova Avaliação",
          color: 0x2b2d31,
          fields: [{ name: "⭐⭐⭐", value: "Atendimento Médio" }],
          footer: { text: "Feita por" + interaction.user.username },
        });
        channel.send({
          embeds: [embed],
        });
      },
    ],
    [
      "four",
      async (interaction) => {
        const channel = index_1.client.channels.cache.get(
          index_1.config.canais.ticketAvaliações
        );
        interaction.update({ components: [] });
        const embed = new discord_js_1.EmbedBuilder({
          title: "Nova Avaliação",
          color: 0x2b2d31,
          fields: [{ name: "⭐⭐⭐⭐", value: "Atendimento Médio / Bom" }],
          footer: { text: "Feita por" + interaction.user.username },
        });
        channel.send({
          embeds: [embed],
        });
      },
    ],
    [
      "five",
      async (interaction) => {
        const channel = index_1.client.channels.cache.get(
          index_1.config.canais.ticketAvaliações
        );
        interaction.update({ components: [] });
        const embed = new discord_js_1.EmbedBuilder({
          title: "Nova Avaliação",
          color: 0x2b2d31,
          fields: [{ name: "⭐⭐⭐⭐⭐", value: "Atendimento Bom" }],
          footer: { text: "Feita por" + interaction.user.username },
        });
        channel.send({
          embeds: [embed],
        });
      },
    ],
  ]),
});
