"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Event = void 0;
class Event {
  constructor(options) {
    Object.assign(this, options);
  }
}
exports.Event = Event;
